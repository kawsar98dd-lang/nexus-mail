/* =========================================
   TRUSTED TOOLS WEB - MAIN SCRIPT (V2.0)
   Author: MD.KAWSER
   Features: Theme Toggle, Search Engine, Firebase Comments
   ========================================= */


document.addEventListener("DOMContentLoaded", function () {
    
    // বর্তমান পেজের URL পাথ চেক করা হচ্ছে
    const path = window.location.pathname;

    // যদি এটি হোম পেজ হয় (index.html বা শুধু /)
    if (path.endsWith("index.html") || path === "/" || path.endsWith("/")) {
        
        // ============================================
        // আপনার হোম পেজের সব অ্যানিমেশন কোড এখানে থাকবে
        // (JSON Architect, Text Genius ইত্যাদির কোড)
        // ============================================
        
        console.log("Home Page Animation Loaded"); 
        
        // উদাহরণ:
        // initFloatingIcons(); 
        // startBackgroundAnimation();

    } else {
        // অন্য কোনো পেজ হলে (যেমন: Terms, Privacy) এখানে কিছুই রান করবে না
        console.log("Animation skipped for inner pages");
    }

});





// --- FIREBASE IMPORTS ---
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, limit, doc, updateDoc, deleteDoc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";

// --- CONFIGURATION ---
const firebaseConfig = { 
    apiKey: "AIzaSyDc9m-lsrzsOC3zVRyXb2xoOOMnyQ7hUic", 
    authDomain: "account-tools-comments.firebaseapp.com", 
    projectId: "account-tools-comments", 
    storageBucket: "account-tools-comments.firebasestorage.app", 
    messagingSenderId: "339954634804", 
    appId: "1:339954634804:web:a0865ac6aa61e76306fa61" 
};

const ADMIN_EMAILS = ["kawser98dd@gmail.com"]; // Add more admins here

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const commentsRef = collection(db, "website_comments");

/* =========================================
   1. THEME TOGGLE SYSTEM (Dynamic)
   ========================================= */
function initThemeSystem() {
    // Create Floating Toggle Button dynamically
    const btn = document.createElement('button');
    btn.id = 'theme-toggle';
    btn.innerHTML = '<i class="fa-solid fa-moon"></i>';
    btn.style.cssText = `
        position: fixed; bottom: 20px; right: 20px;
        width: 50px; height: 50px; border-radius: 50%;
        background: var(--gradient-primary); border: none;
        color: #fff; font-size: 1.2rem; cursor: pointer;
        z-index: 9999; box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        transition: transform 0.3s ease;
    `;
    
    document.body.appendChild(btn);

    // Check Local Storage
    const currentTheme = localStorage.getItem('theme') || 'dark';
    document.body.setAttribute('data-theme', currentTheme);
    updateThemeIcon(currentTheme);

    // Toggle Event
    btn.addEventListener('click', () => {
        const activeTheme = document.body.getAttribute('data-theme');
        const newTheme = activeTheme === 'dark' ? 'light' : 'dark';
        
        document.body.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
        
        // Button Animation
        btn.style.transform = 'rotate(360deg)';
        setTimeout(() => btn.style.transform = 'rotate(0deg)', 300);
    });
}

function updateThemeIcon(theme) {
    const btn = document.getElementById('theme-toggle');
    if(btn) {
        btn.innerHTML = theme === 'dark' 
            ? '<i class="fa-solid fa-sun"></i>' 
            : '<i class="fa-solid fa-moon"></i>';
    }
}

/* =========================================
   2. ADVANCED SEARCH & FILTER (Optimized)
   ========================================= */
function initSearchSystem() {
    const searchInput = document.getElementById('toolSearch');
    const categoryBtns = document.querySelectorAll('.cat-btn');
    const toolCards = document.querySelectorAll('.tool-card');

    if (!searchInput) return;

    // Filter Logic
    const filterTools = (searchTerm, category) => {
        toolCards.forEach(card => {
            const title = card.querySelector('.tool-title').innerText.toLowerCase();
            const desc = card.querySelector('.tool-desc').innerText.toLowerCase();
            const tags = (card.getAttribute('data-name') || "").toLowerCase();
            const cardCat = card.getAttribute('data-category');

            const matchesSearch = title.includes(searchTerm) || desc.includes(searchTerm) || tags.includes(searchTerm);
            const matchesCategory = category === 'all' || cardCat === category;

            if (matchesSearch && matchesCategory) {
                card.classList.remove('hidden');
                // Re-trigger fade animation
                card.style.animation = 'none';
                card.offsetHeight; /* Trigger Reflow */
                card.style.animation = 'fadeIn 0.5s ease forwards';
            } else {
                card.classList.add('hidden');
            }
        });
    };

    // Event: Category Click
    let activeCategory = 'all';
    categoryBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            categoryBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeCategory = btn.getAttribute('data-filter');
            filterTools(searchInput.value.toLowerCase().trim(), activeCategory);
        });
    });

    // Event: Search Input (with Debounce for performance)
    let timeout = null;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            filterTools(e.target.value.toLowerCase().trim(), activeCategory);
        }, 300); // 300ms delay to prevent lag on huge lists
    });
}

/* =========================================
   3. FIREBASE COMMENT SYSTEM logic
   ========================================= */
// Helpers
const escapeHtml = (unsafe) => {
    return unsafe
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
};

const timeAgo = (date) => {
    if (!date) return "Just now";
    const seconds = Math.floor((new Date() - date) / 1000);
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
};

// UI References
let currentUser = null;
const commentsDisplay = document.getElementById("commentsDisplay");
const postBtn = document.getElementById("postBtn");
const msgInput = document.getElementById("userMessage");
const statusMsg = document.getElementById("statusMsg");

// --- Auth State Monitor ---
onAuthStateChanged(auth, (user) => {
    currentUser = user;
    const loggedInView = document.getElementById("logged-in-view");
    const loggedOutView = document.getElementById("logged-out-view");

    if (user) {
        loggedOutView.style.display = "none";
        loggedInView.style.display = "flex";
        document.getElementById("user-profile-pic").src = user.photoURL || "https://api.dicebear.com/9.x/avataaars/svg?seed=Guest";
        document.getElementById("user-name-display").textContent = user.displayName;
        document.getElementById("user-email-display").textContent = user.email;
        
        postBtn.disabled = false;
        postBtn.textContent = "Post Comment";
        postBtn.style.opacity = "1";
        postBtn.style.cursor = "pointer";
    } else {
        loggedOutView.style.display = "block";
        loggedInView.style.display = "none";
        postBtn.disabled = true;
        postBtn.textContent = "Login to Post";
        postBtn.style.opacity = "0.6";
        postBtn.style.cursor = "not-allowed";
    }
});

// --- Auth Actions ---
document.getElementById("loginBtn").addEventListener("click", async () => {
    try { await signInWithPopup(auth, provider); } 
    catch (e) { alert("Login Failed: " + e.message); }
});

document.getElementById("logoutBtn").addEventListener("click", () => {
    if(confirm("Logout from Trusted Tools?")) signOut(auth);
});

// --- CRUD Operations ---

// 1. CREATE COMMENT
if(postBtn) {
    postBtn.addEventListener("click", async () => {
        if (!currentUser) return;
        const msg = msgInput.value.trim();
        if (!msg) return;

        postBtn.disabled = true;
        postBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Posting...';

        try {
            await addDoc(commentsRef, {
                uid: currentUser.uid,
                name: currentUser.displayName,
                photoURL: currentUser.photoURL,
                email: currentUser.email,
                message: msg,
                timestamp: serverTimestamp(),
                isAdmin: ADMIN_EMAILS.includes(currentUser.email),
                parentId: null,
                isEdited: false
            });
            msgInput.value = "";
            statusMsg.textContent = "✅ Posted successfully!";
            setTimeout(() => statusMsg.textContent = "", 3000);
        } catch (e) {
            alert("Error: " + e.message);
        } finally {
            postBtn.disabled = false;
            postBtn.textContent = "Post Comment";
        }
    });
}

// 2. RENDER COMMENTS (Real-time)
const q = query(commentsRef, orderBy("timestamp", "desc"), limit(100));

onSnapshot(q, (snapshot) => {
    if (!commentsDisplay) return;
    
    commentsDisplay.innerHTML = "";
    if (snapshot.empty) {
        commentsDisplay.innerHTML = `<div style="text-align:center; padding:40px; color:var(--text-muted);">
            <i class="fa-regular fa-comments" style="font-size:2rem; margin-bottom:10px;"></i><br>
            No discussions yet. Be the first!
        </div>`;
        return;
    }

    const allDocs = snapshot.docs;
    // Filter root comments (parentId == null)
    const rootComments = allDocs.filter(doc => !doc.data().parentId);

    rootComments.forEach(doc => {
        commentsDisplay.innerHTML += generateCommentHTML(doc, allDocs);
    });
});

// HTML Generator Logic
function generateCommentHTML(docSnapshot, allDocs) {
    const data = docSnapshot.data();
    const id = docSnapshot.id;
    const time = data.timestamp ? timeAgo(data.timestamp.toDate()) : "Posting...";
    
    // Logic for Controls (Edit/Delete)
    let controls = "";
    if (currentUser) {
        const isOwner = currentUser.uid === data.uid;
        const isAdmin = ADMIN_EMAILS.includes(currentUser.email);
        
        if (isOwner || isAdmin) {
            if (isOwner) controls += `<button onclick="window.editComment('${id}')" class="act-btn edit"><i class="fa-solid fa-pen"></i></button>`;
            controls += `<button onclick="window.deleteComment('${id}')" class="act-btn del"><i class="fa-solid fa-trash"></i></button>`;
        }
    }

    // Admin Badge
    const badge = data.isAdmin ? `<span class="badge" style="background:var(--accent-purple); margin-left:5px;">ADMIN</span>` : "";
    const edited = data.isEdited ? `<span style="font-size:0.7em; color:#666;"> (edited)</span>` : "";

    // Recursive Reply Rendering
    const replies = allDocs.filter(d => d.data().parentId === id)
        .sort((a,b) => (a.data().timestamp?.seconds || 0) - (b.data().timestamp?.seconds || 0));
    
    let repliesHTML = "";
    if(replies.length > 0) {
        repliesHTML = `<div class="reply-wrapper">`;
        replies.forEach(r => repliesHTML += generateCommentHTML(r, allDocs));
        repliesHTML += `</div>`;
    }

    return `
    <div class="single-comment" id="comment-${id}">
        <div class="comment-avatar">
            <img src="${data.photoURL}" alt="User">
        </div>
        <div class="comment-content">
            <div class="comment-header">
                <div>
                    <span class="comment-author">${escapeHtml(data.name)}</span> ${badge}
                    <span class="comment-date"> • ${time}</span>
                </div>
            </div>
            <div class="comment-text" id="msg-${id}">${escapeHtml(data.message)}${edited}</div>
            
            <div class="action-bar" style="margin-top:8px; display:flex; gap:10px; opacity:0.8;">
                <button onclick="window.replyComment('${id}', '${escapeHtml(data.name)}')" class="act-btn reply">
                    <i class="fa-solid fa-reply"></i> Reply
                </button>
                ${controls}
            </div>
            ${repliesHTML}
        </div>
    </div>
    <style>
        .act-btn { background:none; border:none; color:var(--text-muted); cursor:pointer; font-size:0.8rem; transition:0.2s; }
        .act-btn:hover { color:var(--accent-cyan); }
        .act-btn.del:hover { color: #ff4444; }
    </style>
    `;
}

/* =========================================
   4. GLOBAL WINDOW FUNCTIONS (For HTML Calls)
   ========================================= */
window.replyComment = async (parentId, name) => {
    if (!currentUser) return alert("Please login to reply.");
    const text = prompt(`Reply to ${name}:`);
    if (text) {
        await addDoc(commentsRef, {
            uid: currentUser.uid,
            name: currentUser.displayName,
            photoURL: currentUser.photoURL,
            email: currentUser.email,
            message: text,
            timestamp: serverTimestamp(),
            isAdmin: ADMIN_EMAILS.includes(currentUser.email),
            parentId: parentId,
            isEdited: false
        });
    }
};

window.editComment = async (docId) => {
    const el = document.getElementById(`msg-${docId}`);
    const oldText = el ? el.innerText.replace(" (edited)", "") : "";
    const newText = prompt("Edit your comment:", oldText);
    
    if (newText && newText !== oldText) {
        await updateDoc(doc(db, "website_comments", docId), {
            message: newText,
            isEdited: true
        });
    }
};

window.deleteComment = async (docId) => {
    if (confirm("Delete this comment permanently?")) {
        await deleteDoc(doc(db, "website_comments", docId));
    }
};


/* =========================================
   5. GLOBAL FOOTER INJECTION (নতুন যুক্ত করা হলো)
   ========================================= */
function loadGlobalFooter() {
    const footerEl = document.getElementById('global-footer');
    if(!footerEl) return;

    const year = new Date().getFullYear();

    footerEl.innerHTML = `
            <footer class="cyber-footer">
        <div class="footer-bg-grid"></div>
        <div class="footer-glow-point"></div>

        <div class="footer-container relative-z">
            
            <div class="footer-top animated-entry">
                <div class="footer-brand">
                    <i class="fa-solid fa-shield-halved brand-icon"></i> 
                    <span class="brand-name">Trusted Tools <span class="highlight">Web</span></span>
                </div>
                <p class="footer-tagline">Your Secure Digital Arsenal. Fast, Free & Private Utilities.</p>
            </div>

           <div class="glass-nav-panel animated-entry delay-1">
    <a href="pages/about.html" class="f-link"><i class="fa-solid fa-circle-info"></i> About</a>
    <a href="pages/contact.html" class="f-link"><i class="fa-solid fa-envelope"></i> Contact</a>
    <a href="pages/privacy-policy.html" class="f-link"><i class="fa-solid fa-user-shield"></i> Privacy</a>
    <a href="pages/terms.html" class="f-link"><i class="fa-solid fa-gavel"></i> Terms</a>
    <a href="pages/disclaimer.html" class="f-link"><i class="fa-solid fa-triangle-exclamation"></i> Disclaimer</a>
</div>

            <div class="footer-bottom animated-entry delay-2">
                <p class="copyright">
                    &copy; 2026 <strong>Trusted Tools Web</strong>. Addicted to Security.
                </p>
                <div class="developer-badge">
                    Designed with <i class="fa-solid fa-code" style="color: var(--accent-color);"></i> by 
                    <a href="https://t.me/Md_Kawser2" target="_blank" class="dev-link glow-effect">MD.KAWSER</a>
                </div>
            </div>
        </div>
    </footer>

    `;
}





// --- INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
    initThemeSystem();
    initSearchSystem();
    loadGlobalFooter(); // <--- এই লাইনটি অবশ্যই থাকতে হবে
    console.log("Trusted Tools Web: System Loaded 🚀");
});
