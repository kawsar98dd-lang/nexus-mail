/* =========================================
   FIREBASE COMMENT SYSTEM
   Only include this file on pages that need comments!
   ========================================= */

import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot, query, orderBy, serverTimestamp, limit, doc, updateDoc, deleteDoc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";

// --- CONFIGURATION ---
const firebaseConfig = { 
    apiKey: "AIzaSyDc9m-lsrzsOC3zVRyXb2xoOOMnyQ7hUic", 
    authDomain: "account-tools-comments.firebaseapp.com", 
    projectId: "account-tools-comments", 
    storageBucket: "account-tools-comments.firebasestorage.app", 
    messagingSenderId: "339954634804", 
    appId: "1:339954634804:web:a0865ac6aa61e76306fa61" 
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const commentsRef = collection(db, "website_comments");
const ADMIN_EMAILS = ["kawser98dd@gmail.com"];

// --- UI References ---
let currentUser = null;
const commentsDisplay = document.getElementById("commentsDisplay");
const postBtn = document.getElementById("postBtn");
const msgInput = document.getElementById("userMessage");

// --- Auth Monitor ---
onAuthStateChanged(auth, (user) => {
    currentUser = user;
    const loggedInView = document.getElementById("logged-in-view");
    const loggedOutView = document.getElementById("logged-out-view");

    if (loggedInView && loggedOutView) {
        if (user) {
            loggedOutView.style.display = "none";
            loggedInView.style.display = "flex";
            document.getElementById("user-profile-pic").src = user.photoURL;
            document.getElementById("user-name-display").textContent = user.displayName;
            if(postBtn) postBtn.disabled = false;
        } else {
            loggedOutView.style.display = "block";
            loggedInView.style.display = "none";
            if(postBtn) postBtn.disabled = true;
        }
    }
});

// --- Button Events ---
const loginBtn = document.getElementById("loginBtn");
if(loginBtn) loginBtn.addEventListener("click", () => signInWithPopup(auth, provider).catch(console.error));

const logoutBtn = document.getElementById("logoutBtn");
if(logoutBtn) logoutBtn.addEventListener("click", () => signOut(auth));

// --- Post Logic ---
if(postBtn) {
    postBtn.addEventListener("click", async () => {
        if (!currentUser || !msgInput.value.trim()) return;
        postBtn.disabled = true;
        try {
            await addDoc(commentsRef, {
                uid: currentUser.uid,
                name: currentUser.displayName,
                photoURL: currentUser.photoURL,
                email: currentUser.email,
                message: msgInput.value.trim(),
                timestamp: serverTimestamp(),
                isAdmin: ADMIN_EMAILS.includes(currentUser.email)
            });
            msgInput.value = "";
        } catch (e) { alert(e.message); }
        postBtn.disabled = false;
    });
}

// --- Render Logic (Realtime) ---
if (commentsDisplay) {
    const q = query(commentsRef, orderBy("timestamp", "desc"), limit(50));
    onSnapshot(q, (snapshot) => {
        commentsDisplay.innerHTML = snapshot.docs.map(doc => {
            const data = doc.data();
            const badge = data.isAdmin ? `<span style="background:purple;color:white;font-size:10px;padding:2px 4px;border-radius:4px;">ADMIN</span>` : "";
            return `
            <div style="background:rgba(255,255,255,0.05); padding:10px; border-radius:8px; margin-bottom:10px; border:1px solid rgba(255,255,255,0.1);">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:5px;">
                    <img src="${data.photoURL}" style="width:30px; height:30px; border-radius:50%;">
                    <strong style="color:white; font-size:0.9rem;">${data.name} ${badge}</strong>
                </div>
                <div style="color:#ccc; font-size:0.9rem; padding-left:40px;">${data.message}</div>
            </div>`;
        }).join('');
    });
}
